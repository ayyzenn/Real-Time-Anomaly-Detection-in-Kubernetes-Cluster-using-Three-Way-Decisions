# Install utilities

Contains utility scripts for preparing a target platform.

